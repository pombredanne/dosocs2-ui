(function(){//Track uploaded items

Items = new Mongo.Collection('items');

}).call(this);
